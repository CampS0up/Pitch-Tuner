package com.example.pitchapp

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.util.Log
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "PitchApp"

        // Nordic UART / ESP32 service+chars
        val SERVICE_UUID: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
        val RX_UUID: UUID      = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E") // phone -> ESP32
        val TX_UUID: UUID      = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E") // ESP32 -> phone (notify)

        val CCCD_UUID: UUID    = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    // UI
    private lateinit var btnConnect: Button
    private lateinit var txtStatus: TextView
    private lateinit var txtCurrentNote: TextView
    private lateinit var txtCurrentFreq: TextView
    private lateinit var txtCurrentCents: TextView
    private lateinit var txtCurrentProb: TextView
    private lateinit var edtNote: EditText
    private lateinit var btnPlayNote: Button
    private lateinit var btnMute: Button
    private lateinit var btnToggleLog: Button
    private lateinit var txtLogResult: TextView

    // BLE
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private var isScanning = false

    private var gatt: BluetoothGatt? = null
    private var txCharacteristic: BluetoothGattCharacteristic? = null
    private var rxCharacteristic: BluetoothGattCharacteristic? = null

    private var connected = false
    private var connecting = false

    // Logging
    private var logging = false
    private var logStartTime: Long = 0L
    private val logCents = ArrayList<Float>()

    // Permissions (Android 12+)
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) {
            initBluetooth()
        } else {
            Toast.makeText(this, "Bluetooth permissions denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Bind UI
        btnConnect = findViewById(R.id.btnConnect)
        txtStatus = findViewById(R.id.txtStatus)
        txtCurrentNote = findViewById(R.id.txtCurrentNote)
        txtCurrentFreq = findViewById(R.id.txtCurrentFreq)
        txtCurrentCents = findViewById(R.id.txtCurrentCents)
        txtCurrentProb = findViewById(R.id.txtCurrentProb)
        edtNote = findViewById(R.id.edtNote)
        btnPlayNote = findViewById(R.id.btnPlayNote)
        btnMute = findViewById(R.id.btnMute)
        btnToggleLog = findViewById(R.id.btnToggleLog)
        txtLogResult = findViewById(R.id.txtLogResult)

        btnConnect.setOnClickListener {
            if (connected || connecting) {
                disconnectGatt()
            } else {
                startBleFlow()
            }
        }

        btnPlayNote.setOnClickListener {
            if (!connected || rxCharacteristic == null) {
                Toast.makeText(this, "Not connected", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val note = edtNote.text.toString().trim()
            if (note.isEmpty()) {
                Toast.makeText(this, "Enter a note like C4, A4", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            sendCommand("PLAY NOTE=$note\n")
        }

        btnMute.setOnClickListener {
            if (connected && rxCharacteristic != null) {
                sendCommand("MUTE\n")
            }
        }

        btnToggleLog.setOnClickListener {
            toggleLogging()
        }

        checkAndRequestPermissions()
    }

    private fun checkAndRequestPermissions() {
        val toRequest = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }

        if (toRequest.isNotEmpty()) {
            permissionLauncher.launch(toRequest.toTypedArray())
        } else {
            initBluetooth()
        }
    }

    private fun initBluetooth() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter

        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            Toast.makeText(this, "Please enable Bluetooth", Toast.LENGTH_SHORT).show()
        } else {
            bluetoothLeScanner = bluetoothAdapter!!.bluetoothLeScanner
        }
    }

    private fun startBleFlow() {
        if (bluetoothAdapter == null || bluetoothLeScanner == null) {
            Toast.makeText(this, "Bluetooth not ready", Toast.LENGTH_SHORT).show()
            return
        }
        startScan()
    }

    // =============== SCAN & CONNECT ===============

    private fun startScan() {
        if (isScanning) return

        val scanner = bluetoothLeScanner ?: return
        isScanning = true
        connecting = true
        txtStatus.text = "Status: Scanning for device..."
        btnConnect.text = "Cancel"

        val filters = listOf(
            ScanFilter.Builder()
                .setServiceUuid(ParcelUuid(SERVICE_UUID))
                .build()
        )
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        scanner.startScan(filters, settings, scanCallback)
    }

    private fun stopScan() {
        if (!isScanning) return
        bluetoothLeScanner?.stopScan(scanCallback)
        isScanning = false
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            super.onScanResult(callbackType, result)
            val device = result.device
            Log.d(TAG, "Found device: ${device.name} - ${device.address}")

            stopScan()
            connectToDevice(device)
        }

        override fun onScanFailed(errorCode: Int) {
            super.onScanFailed(errorCode)
            Log.e(TAG, "Scan failed: $errorCode")
            isScanning = false
            connecting = false
            runOnUiThread {
                txtStatus.text = "Status: Scan failed ($errorCode)"
                btnConnect.text = "Connect"
            }
        }
    }

    private fun connectToDevice(device: BluetoothDevice) {
        runOnUiThread {
            txtStatus.text = "Status: Connecting to ${device.address}..."
            btnConnect.text = "Cancel"
        }
        connecting = true
        gatt = device.connectGatt(this, false, gattCallback)
    }

    private fun disconnectGatt() {
        stopScan()
        logging = false
        btnToggleLog.text = "Start Accuracy Log"

        gatt?.disconnect()
        gatt?.close()
        gatt = null

        connected = false
        connecting = false
        runOnUiThread {
            txtStatus.text = "Status: Disconnected"
            btnConnect.text = "Connect"
        }
        txCharacteristic = null
        rxCharacteristic = null
    }

    private val gattCallback = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                Log.e(TAG, "Connection state change error: $status")
                runOnUiThread {
                    txtStatus.text = "Status: Connection error ($status)"
                    disconnectGatt()
                }
                return
            }

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.d(TAG, "Connected, discovering services")
                runOnUiThread {
                    txtStatus.text = "Status: Discovering services..."
                }
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.d(TAG, "Disconnected")
                runOnUiThread {
                    disconnectGatt()
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                Log.e(TAG, "Services discovered error: $status")
                return
            }

            val service = gatt.getService(SERVICE_UUID)
            if (service == null) {
                Log.e(TAG, "UART service not found")
                runOnUiThread {
                    txtStatus.text = "Status: Service not found"
                }
                return
            }

            val tx = service.getCharacteristic(TX_UUID)
            val rx = service.getCharacteristic(RX_UUID)
            if (tx == null || rx == null) {
                Log.e(TAG, "UART characteristics not found")
                runOnUiThread {
                    txtStatus.text = "Status: Characteristics not found"
                }
                return
            }

            txCharacteristic = tx
            rxCharacteristic = rx

            // Enable notifications
            gatt.setCharacteristicNotification(tx, true)
            val cccd = tx.getDescriptor(CCCD_UUID)
            if (cccd != null) {
                cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                gatt.writeDescriptor(cccd)
            }

            connected = true
            connecting = false
            runOnUiThread {
                txtStatus.text = "Status: Connected"
                btnConnect.text = "Disconnect"
            }
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (characteristic.uuid == TX_UUID) {
                val data = characteristic.value ?: return
                val text = data.toString(Charsets.UTF_8)
                Log.d(TAG, "RX JSON: $text")
                handleJsonFromEsp(text)
            }
        }
    }

    private fun handleJsonFromEsp(jsonStr: String) {
        try {
            val obj = JSONObject(jsonStr)

            val f0 = obj.optDouble("f0", 0.0)
            val note = obj.optString("note", "--")
            val cents = obj.optDouble("cents", 0.0)
            val prob = obj.optDouble("prob", 0.0)

            runOnUiThread {
                txtCurrentNote.text = "Note: $note"
                txtCurrentFreq.text = String.format(Locale.US, "f0: %.2f Hz", f0)
                txtCurrentCents.text = String.format(Locale.US, "Cents: %.1f", cents)
                txtCurrentProb.text = String.format(Locale.US, "Confidence: %.2f", prob)
            }

            if (logging && note != "--" && !cents.isNaN()) {
                synchronized(logCents) {
                    logCents.add(abs(cents.toFloat()))
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "JSON parse error: ${e.message}")
        }
    }

    private fun sendCommand(cmd: String) {
        val g = gatt ?: return
        val rx = rxCharacteristic ?: return

        rx.value = cmd.toByteArray(Charsets.UTF_8)
        val ok = g.writeCharacteristic(rx)
        if (!ok) {
            Log.e(TAG, "writeCharacteristic failed for: $cmd")
        }
    }

    private fun toggleLogging() {
        logging = !logging
        if (logging) {
            synchronized(logCents) {
                logCents.clear()
            }
            logStartTime = System.currentTimeMillis()
            btnToggleLog.text = "Stop Accuracy Log"
            txtLogResult.text = "Logging... sing and hold pitch!"
        } else {
            val endTime = System.currentTimeMillis()
            val durationSec = (endTime - logStartTime) / 1000.0

            val samples: List<Float>
            synchronized(logCents) {
                samples = ArrayList(logCents)
            }

            btnToggleLog.text = "Start Accuracy Log"

            if (samples.isEmpty()) {
                txtLogResult.text = "No samples logged."
            } else {
                val avg = samples.sum() / samples.size
                val max = samples.maxOrNull() ?: 0f
                txtLogResult.text = String.format(
                    Locale.US,
                    "Last log:\nDuration: %.1f s\nSamples: %d\nAvg error: %.1f cents\nMax error: %.1f cents",
                    durationSec, samples.size, avg, max
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnectGatt()
    }
}
